### JavaScript Advanced – DOM, Functions, and API

---

### ✅ Features Covered:

1. **DOM Manipulation**
   - Created a `<p>` element using JavaScript
   - Set its content dynamically
   - Appended it to the page using `document.body.appendChild()`

2. **Function Binding**
   - Used `.bind()` to bind object methods to their correct `this` context
   - Example: calculating area from an object with `width` and `length`

3. **Closures**
   - Created closure-based functions like `changeMode` that remember style settings

4. **Performance Measurement**
   - Used `performance.now()` to measure how long a function runs
   - Called a prime-number-counting function 100 times and logged execution time

5. **JavaScript Event Loop**
   - Used `setTimeout(..., 0)` to push work to the end of the execution stack

6. **API Calls with XMLHttpRequest**
   - Fetched Stack Overflow intro text from Wikipedia
   - Passed response to a callback function (`createElement`) to display it on the page

---

### ✅ Example Functions:

- `createElement(data)` – creates and appends a paragraph
- `queryWikipedia(callback)` – fetches data and calls the callback
- `countPrimeNumbers()` – counts primes between 2 and 100
- `changeMode(...)` – creates and applies a page style using a closure